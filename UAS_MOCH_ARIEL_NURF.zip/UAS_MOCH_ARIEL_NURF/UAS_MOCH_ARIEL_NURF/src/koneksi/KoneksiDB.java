package koneksi; 

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class KoneksiDB {
    private static Connection koneksi;

    public static Connection getKoneksi() {
        if (koneksi == null) {
            try {
                String url = "jdbc:derby://localhost:1527/penjualan_rumah";
                String user = "users";
                String pass = "admin123";
                koneksi = DriverManager.getConnection(url, user, pass);
                System.out.println("Koneksi BERHASIL");
            } catch (SQLException e) {
                System.out.println("Koneksi GAGAL: " + e.getMessage());
            }
        }
        return koneksi;
    }
}

